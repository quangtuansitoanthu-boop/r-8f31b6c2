import { ROSARY_PHRASES, type RosaryPhrase } from './guided-sessions';

export const NAME_COPYING_ROUND_SIZE = 108;
export const NAME_COPYING_MANTRA_LEGACY_LABELS = ['Om Mani Pad Me Hum', 'Om Mani PAD ME HUM'];
type RosaryName = Extract<RosaryPhrase, `Nam mô ${string}`>;
export type NameCopyingPhrase = RosaryName | 'Ôm Ma Ni Pát Mê Hùm';
export const NAME_COPYING_PHRASES: NameCopyingPhrase[] = [
  ...ROSARY_PHRASES.filter((phrase): phrase is RosaryName => phrase.startsWith('Nam mô ')),
  'Ôm Ma Ni Pát Mê Hùm'
];

export function nameCopyingChoiceId(phrase: NameCopyingPhrase): string {
  return phrase.normalize('NFD').replace(/\p{M}/gu, '').toLowerCase().replace(/đ/g, 'd').replace(/[^a-z0-9]+/g, '-');
}

export function matchesNameCopyingPhrase(line: string, phrase: NameCopyingPhrase): boolean {
  const normalize = (text: string) => text.normalize('NFC').trim().replace(/\s+/gu, ' ').toLocaleUpperCase('vi-VN');
  return normalize(line) === normalize(phrase);
}

export function isNameCopyingNextKey(key: string, keyCode?: number): boolean {
  return key === 'Enter' || key === 'Tab' || keyCode === 13 || keyCode === 9;
}

export interface ShouldAdvanceKeyParams {
  key: string;
  keyCode?: number;
  isComposing?: boolean;
  currentLine?: string;
  target?: NameCopyingPhrase;
  lastAdvanceTime: number;
  now?: number;
  cooldownMs?: number;
}

export function shouldAdvanceNameCopyingKey({
  key,
  keyCode,
  isComposing = false,
  lastAdvanceTime,
  now = Date.now(),
  cooldownMs = 400
}: ShouldAdvanceKeyParams): boolean {
  if (!isNameCopyingNextKey(key, keyCode)) return false;
  if (isComposing) return false;
  if (now - lastAdvanceTime < cooldownMs) return false;
  return true;
}
